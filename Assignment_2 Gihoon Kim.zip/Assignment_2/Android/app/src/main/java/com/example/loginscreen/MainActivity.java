package com.example.loginscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static int errorCount = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText userNameEditText = findViewById(R.id.usernameEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        final Button loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(onClickLoginButton);

        /*
        App 2 Challenge!
        to set up this functionality in the Login Screen app
         */
        userNameEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER)
                    loginButton.performClick();
                return true;
            }
        });
        passwordEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (loginButton.isClickable())
                    if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER)
                        loginButton.performClick();
                return true;
            }
        });
    }

    private View.OnClickListener onClickLoginButton = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            Button loginButton = findViewById(R.id.loginButton);
            EditText userNameEditText = findViewById(R.id.usernameEditText);
            EditText passwordEditText = findViewById(R.id.passwordEditText);
            TextView errorTextView = findViewById(R.id.errorTextView);

            String userName = userNameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            LoginManager loginManager = new LoginManager(userName, password);

            if(loginManager.hasValidCredentials()) {
                // Success
                errorTextView.setVisibility(View.INVISIBLE);
                // The failed attempts should reset if they get the login information correct
                errorCount = 0;
            } else {
                // False
                errorCount++;
                errorTextView.setText(R.string.error_text);
                // Modify the error message to show the user how many attempts they have left (of 3 total attempts)
                errorTextView.append(" Attempts : " + errorCount + " / 3" + "\n");
                if (errorCount == 3) {
                    errorTextView.append("You have failed 3 attempts. Try later.");
                    loginButton.setAlpha(0.5f);
                    loginButton.setClickable(false);
                }
                errorTextView.setVisibility(View.VISIBLE);
            }
        }
    };
}
