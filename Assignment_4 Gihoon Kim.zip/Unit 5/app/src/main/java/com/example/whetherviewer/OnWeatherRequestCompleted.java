package com.example.whetherviewer;

public interface OnWeatherRequestCompleted {

    void onTaskCompleted(WeatherData data);
}
