package com.example.whetherviewer;

public class ApiException extends Exception {

    public ApiException(String message) {
        super(message);
    }
}
