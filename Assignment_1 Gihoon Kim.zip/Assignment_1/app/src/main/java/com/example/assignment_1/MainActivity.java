package com.example.assignment_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView countTextView;
    private int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        count = 0;

        Button countButton = findViewById(R.id.countButton);
        countTextView = findViewById(R.id.countTextView);
        Button resetButton = findViewById(R.id.resetButton);

        countButton.setOnClickListener(onClickCounterButton);
        resetButton.setOnClickListener(onClickResetButton);
    }

    private View.OnClickListener onClickCounterButton = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            count++;
            countTextView.setText(String.valueOf(count));
        }
    };

    private View.OnClickListener onClickResetButton = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            count = 0;
            countTextView.setText(String.valueOf(count));
        }
    };
}
